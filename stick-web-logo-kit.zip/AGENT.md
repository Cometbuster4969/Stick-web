# Stick-web — Logo swap + robots/sitemap

## 0. Target check (read first)

- **You are working in:** `Cometbuster4969/Stick-web` — the marketing/showcase site,
  live at `https://stick-web.vercel.app/` (Vite + React SPA, `index.html` at repo root,
  static files in `public/`).
- **NOT this repo:** `Cometbuster4969/STICKBLADE-ARENA` is the Fight Night webapp
  (`https://stickblade-arena.vercel.app/`). Do not touch it. Do not copy its branding.
- Layout below was validated against the showcase source snapshot (Sept 2026:
  routes `/`, `/fights`, `/research`, `/about` in `src/router.jsx`). If your checkout
  differs slightly, adapt paths but keep the same intent.

## 1. Goal & scope

1. Replace the logo and **all** related brand images with the new kit (this zip's `public/`).
2. Add **only** these two new root files: `robots.txt`, `sitemap.xml` (provided, ready-made).
3. Nothing else: no redesign, no new dependencies, no theme/CSP/routing changes,
   no new pages. Keep the whole change in **one commit**.

## 2. Unpack

Extract this zip at the **repo root** so its `public/` merges into the repo's `public/`.
This `AGENT.md` is instructions only — **do not commit it** to the repo.

File map (zip → repo, same relative path; overwrite on conflict):

| File | Purpose |
|---|---|
| `public/favicon.ico` | Browser tab icon (multi-size ICO) |
| `public/favicon-16x16.png` | Small tab icon |
| `public/favicon-32x32.png` | Retina tab icon |
| `public/apple-touch-icon.png` | iOS home-screen icon (180px) |
| `public/android-chrome-192x192.png` | Staged for a future web manifest (ship file, do not reference yet) |
| `public/android-chrome-512x512.png` | Same as above |
| `public/og-image.png` | 1200×630 link-preview card for X/LinkedIn/Discord |
| `public/stickblade-arena-mark.png` | Transparent duelist mark, 512px (in-app logo use) |
| `public/lockup-horizontal.png` | Mark + STICKBLADE ARENA wordmark, horizontal (footer/about/press) |
| `public/lockup-stacked.png` | Same lockup, stacked (hero/poster use) |
| `public/robots.txt` | NEW — allow all + sitemap pointer |
| `public/sitemap.xml` | NEW — the 4 clean-path routes (see §5) |

## 3. Delete dead weight

```bash
# favicon.svg is an unreferenced leftover from the old icon set — remove it:
git rm -q public/favicon.svg 2>/dev/null || rm -f public/favicon.svg
# remove vite.svg ONLY if nothing references it:
grep -rn "vite\.svg" index.html src public 2>/dev/null || git rm -q public/vite.svg 2>/dev/null || true
```

## 4. `index.html` — required `<head>` edits

Keep everything else byte-for-byte (title, meta description, `theme-color`,
preconnect, CSP — do not touch). Make exactly these changes:

**a) Favicon links** — replace the existing icon block with:

```html
<link rel="icon" href="/favicon.ico" sizes="any" />
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
```

**b) Social preview tags** — add after the meta description (image URLs MUST be
absolute — relative `og:image` breaks link unfurls):

```html
<meta property="og:type" content="website" />
<meta property="og:site_name" content="STICKBLADE ARENA" />
<meta property="og:title" content="STICKBLADE ARENA — AI Olympics with Swords" />
<meta property="og:description" content="STICKBLADE ARENA — Two language models sword-fight in real 2D physics. You pick the sharp zone, they fight blind, you vote blind. AI Olympics with swords." />
<meta property="og:url" content="https://stick-web.vercel.app/" />
<meta property="og:image" content="https://stick-web.vercel.app/og-image.png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:image:alt" content="Stickblade Arena — two AIs enter, one leaves" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="STICKBLADE ARENA — AI Olympics with Swords" />
<meta name="twitter:description" content="STICKBLADE ARENA — Two language models sword-fight in real 2D physics. You pick the sharp zone, they fight blind, you vote blind. AI Olympics with swords." />
<meta name="twitter:image" content="https://stick-web.vercel.app/og-image.png" />
```

(One static `og:url` for the whole SPA is correct — per-page tags would need SSR.)

## 5. Swap every in-app logo reference

Find them all first — there must be zero left pointing at old assets afterwards:

```bash
grep -rniE "favicon|logo|vite\.svg|apple-touch|android-chrome|og-image|\.ico" \
  index.html src public --include="*.html" --include="*.jsx" --include="*.js" \
  --include="*.css" --include="*.json" --include="*.md" | grep -v node_modules
```

Rules:

- Every favicon/logo reference must resolve to the new kit files above
  (navbar/footer/hero logo → `/stickblade-arena-mark.png`; wide footer/about
  placement → `/lockup-horizontal.png`).
- All image URLs stay **local** (`/…`) — the CSP only allows `img-src 'self' data:`,
  so never hotlink.
- Do NOT invent new logo placements or restyle anything: text-only brand wordmarks
  stay as-is unless a logo `<img>` slot already exists there.
- Note: the Sept 2026 snapshot has **no** in-app logo `<img>` (only favicons in
  `index.html`). If your checkout is the same, this step is a verified no-op —
  say so in your summary instead of forcing a change.

## 6. robots.txt / sitemap.xml notes

- Both live in `public/` → Vite/Vercel serve them automatically at
  `/robots.txt` and `/sitemap.xml`. Do not move them into `src/`.
- `vercel.json` uses explicit per-route rewrites (`/fights`, `/research`, `/about`
  → `/index.html`) with **no catch-all**, so the two files are not shadowed.
  Do not add rewrites for them.
- Sitemap lists exactly the 4 routes in `src/router.jsx` `PAGES`
  (clean paths, no trailing slash; the 404 page is intentionally excluded).
  If routes changed, update `sitemap.xml` to match `PAGES`.

## 7. Build & verify

```bash
npm ci && npm run build
```

Then confirm (local preview or the deploy preview — same checks):

- [ ] `curl -sI <preview>/robots.txt` → 200, `content-type: text/plain`
- [ ] `curl -sI <preview>/sitemap.xml` → 200, `content-type: application/xml` (or `text/xml`)
- [ ] `curl -sI <preview>/favicon.ico` → 200 (not the old byte size)
- [ ] `curl -sI <preview>/og-image.png` → 200, `content-type: image/png`
- [ ] View-source shows the §4 favicon + OG/Twitter tags; `og:image` is absolute
- [ ] Tab shows the orange duelist favicon (hard-refresh — favicons cache hard)
- [ ] Link unfurl renders the card (check with opengraph.xyz or the X/LinkedIn
      post inspector — crawlers must be able to fetch `og-image.png` anonymously)
- [ ] `/`, `/fights`, `/research`, `/about` all still 200
- [ ] `git status` shows only: new/overwritten files in `public/`, `index.html`
      modified, `favicon.svg` deleted. Nothing else.

## 8. Commit & push

One commit, e.g. `assets: new arena logo kit + robots/sitemap`, then push.
Rollback is `git revert` on that single commit.

## Appendix — brand values (do not recolor anything)

- Arena orange `#FF711F` · background `#0D0B09` · off-white `#F2EDE6 ·
  wordmark font Bebas Neue (baked into the lockup PNGs — no font install needed).
